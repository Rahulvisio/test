Contributors
============

All contributors (by number of commits):

- Mike Boers <github@mikeboers.com>; `@mikeboers <https://github.com/mikeboers>`_

* Jeremy Lainé <jeremy.laine@m4x.org>; `@jlaine <https://github.com/jlaine>`_
* Mark Reid <mindmark@gmail.com>; `@markreidvfx <https://github.com/markreidvfx>`_

- Vidar Tonaas Fauske <vidartf@gmail.com>; `@vidartf <https://github.com/vidartf>`_
- Billy Shambrook <billy.shambrook@gmail.com>; `@billyshambrook <https://github.com/billyshambrook>`_
- Casper van der Wel <caspervdw@gmail.com>
- Tadas Dailyda <tadas@dailyda.com>

* Xinran Xu <xxr@megvii.com>; `@xxr3376 <https://github.com/xxr3376>`_
* Dan Allan <daniel.b.allan@gmail.com>; `@danielballan <https://github.com/danielballan>`_
* Alireza Davoudi <davoudialireza@gmail.com>; `@adavoudi <https://github.com/adavoudi>`_
* Moritz Kassner <moritzkassner@gmail.com>; `@mkassner <https://github.com/mkassner>`_
* Thomas A Caswell <tcaswell@gmail.com>; `@tacaswell <https://github.com/tacaswell>`_
* Ulrik Mikaelsson <ulrik.mikaelsson@magine.com>; `@rawler <https://github.com/rawler>`_
* Wel C. van der <wel@Physics.LeidenUniv.nl>
* Will Patera <willpatera@gmail.com>; `@willpatera <https://github.com/willpatera>`_

- rutsh <Eugene.Krokhalev@gmail.com>
- Christoph Rackwitz <christoph.rackwitz@gmail.com>
- Johannes Erdfelt <johannes@erdfelt.com>
- Karl Litterfeldt <kalle.litterfeldt@gmail.com>; `@litterfeldt <https://github.com/litterfeldt>`_
- Martin Larralde <martin.larralde@ens-cachan.fr>
- Miles Kaufmann <mkfmnn@gmail.com>
- Radek Senfeld <rush@logic.cz>; `@radek-senfeld <https://github.com/radek-senfeld>`_
- Ian Lee <IanLee1521@gmail.com>
- Arthur Barros <arthbarros@gmail.com>
- Gemfield <gemfield@civilnet.cn>
- mephi42 <mephi42@gmail.com>
- Manuel Goacolou <mgoacolou@cls.fr>
- Ömer Sezgin Uğurlu <omer@ugurlu.org>
- Orivej Desh <orivej@gmx.fr>
- Brendan Long <self@brendanlong.com>; `@brendanlong <https://github.com/brendanlong>`_
- Tom Flanagan <theknio@gmail.com>
- Tim O'Shea <tim.oshea753@gmail.com>
- Tim Ahpee <timah@blackmagicdesign.com>
- Jonas Tingeborn <tinjon@gmail.com>
- Vasiliy Kotov <vasiliy.kotov@itechart-group.com>
- Koichi Akabe <vbkaisetsu@gmail.com>
- David Joy <videan42@gmail.com>
